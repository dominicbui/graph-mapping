def get_screen_res():
    """
    Funcion that check current screen resolution. Raise OSError if can't recognise OS!
    * :return: (width, height) tuple with screen resolution.
    """
    import platform

    system = platform.system()
    if 'Linux' in system:
        import subprocess
        import re
        output = subprocess.Popen('xrandr | grep "\*" | cut -d" " -f4', shell=True, stdout=subprocess.PIPE)
        output = output.communicate()[0]
        valid_res = lambda x: re.match('^\d{3,4}x\d{3,4}$', x)
        if not valid_res(output):
            output = subprocess.Popen(' xdpyinfo | grep dimensions | cut -d" " -f7', shell=True, stdout=subprocess.PIPE)
            output = output.communicate()[0]
        if not valid_res(output):
            raise OSError(
                "Humanity need more time to come up with efficient way of checking screen resolution of your hamster")
        width, height = map(int, output.split('x'))
        # width, height = [int(x) for x in "b'1920x1080\n'".split('\'')[1].split('\n')[0].split('x')]
    elif 'Windows' in system:
        from win32api import GetSystemMetrics
        width = int(GetSystemMetrics(0))
        height = int(GetSystemMetrics(1))
    else:  # can't recognise OS
        raise OSError("get_screen_res function can't recognise your OS")

    return [width, height]
